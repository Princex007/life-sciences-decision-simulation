"""Forecast implementations."""
