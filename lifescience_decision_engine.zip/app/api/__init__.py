"""FastAPI surface."""
