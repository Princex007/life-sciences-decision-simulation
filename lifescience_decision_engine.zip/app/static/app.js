const byId = id => document.getElementById(id);
const agentBox = byId('agents'), actionBox = byId('actions'), triggerBox = byId('triggers');
let currentId = null, saved = false, resultScenarios = [], nodeIndex = {};

function setStatus(text, bad=false){byId('status').textContent=text;byId('status').style.color=bad?'#a2352d':'#58706e';}
function parseBox(id, fallback){try{return JSON.parse(byId(id).value||JSON.stringify(fallback));}catch(e){throw new Error(`${id}: ${e.message}`);}}
function typedValue(value,type){if(type==='number')return Number(value);if(type==='boolean')return value==='true';if(type==='object'){try{return JSON.parse(value);}catch{return value;}}return value;}
function addVariableRow(name='',value='',meta={}){
  const tr=document.createElement('tr');
  const types=['number','string','boolean','object'];let type=meta.type|| (typeof value==='number'?'number':typeof value==='boolean'?'boolean':typeof value==='object'?'object':'string');
  const cells=[document.createElement('td'),document.createElement('td'),document.createElement('td'),document.createElement('td'),document.createElement('td'),document.createElement('td'),document.createElement('td')];
  const nameInput=document.createElement('input');nameInput.value=name;nameInput.placeholder='variable_name';
  const typeSelect=document.createElement('select');types.forEach(t=>{const o=document.createElement('option');o.value=t;o.textContent=t;if(t===type)o.selected=true;typeSelect.append(o)});
  const valueInput=document.createElement('input');valueInput.value=typeof value==='object'?JSON.stringify(value):String(value);valueInput.placeholder='value';
  const minInput=document.createElement('input');minInput.value=meta.min??'';minInput.placeholder='optional';
  const maxInput=document.createElement('input');maxInput.value=meta.max??'';maxInput.placeholder='optional';
  const descInput=document.createElement('input');descInput.value=meta.description||'';descInput.placeholder='optional';
  const remove=document.createElement('button');remove.className='remove-row';remove.textContent='Remove';remove.onclick=()=>tr.remove();
  [nameInput,typeSelect,valueInput,minInput,maxInput,descInput,remove].forEach((el,i)=>cells[i].append(el));cells.forEach(c=>tr.append(c));byId('variables').append(tr);
}
function loadDefinition(d,isSaved=false){
  currentId=d.metadata.id; saved=isSaved;byId('simId').value=d.metadata.id;byId('name').value=d.metadata.name;byId('description').value=d.metadata.description||'';
  byId('horizon').value=d.settings.time_horizon;byId('step').value=d.settings.step_duration;byId('stepUnit').value=d.settings.step_unit;
  byId('forecast').value=d.forecast_model_id||'state_metrics';byId('policy').value=d.scenario_generation.policy;
  byId('limit').value=d.scenario_generation.max_scenarios??9;byId('safety').value=d.scenario_generation.safety_limit??1000;
  byId('variables').replaceChildren();const vars=d.initial_world_state.variables||{};const metadata=d.world_variable_metadata||{};
  Object.entries(vars).forEach(([k,v])=>addVariableRow(k,v,metadata[k]||{}));
  agentBox.value=JSON.stringify(d.agents||[],null,2);actionBox.value=JSON.stringify(d.action_definitions||[],null,2);
  triggerBox.value=JSON.stringify(d.trigger_definitions||[],null,2);byId('transitions').value=JSON.stringify(d.transition_rules||[],null,2);
  byId('initialEvents').value=JSON.stringify(d.settings.initial_events||[],null,2);byId('scheduledEvents').value=JSON.stringify(d.settings.scheduled_events||[],null,2);
  byId('errors').textContent='';clearResults();setStatus(isSaved?'Loaded saved simulation':'Template loaded');
}
function blankDefinition(){return {metadata:{id:'new-simulation',name:'New Simulation',description:'',domain:'general'},initial_world_state:{variables:{}},world_variable_metadata:{},agents:[],action_definitions:[],trigger_definitions:[],transition_rules:[],settings:{time_horizon:4,step_duration:1,step_unit:'round',initial_events:[{id:'start',time:0,event_type:'simulation_start',description:'Simulation begins'}],scheduled_events:[]},forecast_model_id:'state_metrics',scenario_generation:{policy:'diversity',max_scenarios:9,diversity_by_agents:[],safety_limit:1000}};}
function definitionFromForm(){
  const variables={}, variableMetadata={};
  [...byId('variables').rows].forEach(row=>{const [name,type,value,min,max,description]=[...row.querySelectorAll('input,select')];if(!name.value.trim())return;variables[name.value.trim()]=typedValue(value.value,type.value);const m={type:type.value};if(min.value!=='')m.min=Number(min.value);if(max.value!=='')m.max=Number(max.value);if(description.value)m.description=description.value;variableMetadata[name.value.trim()]=m;});
  const id=byId('simId').value.trim();if(!id)throw new Error('Definition ID is required.');
  return {metadata:{id,name:byId('name').value.trim(),description:byId('description').value,domain:'general'},initial_world_state:{time:0,variables},world_variable_metadata:variableMetadata,
    agents:parseBox('agents',[]),action_definitions:parseBox('actions',[]),trigger_definitions:parseBox('triggers',[]),transition_rules:parseBox('transitions',[]),
    settings:{time_horizon:Number(byId('horizon').value),step_duration:Number(byId('step').value),step_unit:byId('stepUnit').value,
      initial_events:parseBox('initialEvents',[]),scheduled_events:parseBox('scheduledEvents',[])},forecast_model_id:byId('forecast').value||null,
    scenario_generation:{policy:byId('policy').value,max_scenarios:Number(byId('limit').value),diversity_by_agents:parseBox('agents',[]).map(agent=>agent.id),safety_limit:Number(byId('safety').value)}};
}
async function request(url,options={}){const response=await fetch(url,{headers:{'Content-Type':'application/json',...(options.headers||{})},...options});let data;try{data=await response.json();}catch{data={};}if(!response.ok){const detail=data.detail;throw new Error(typeof detail==='string'?detail:detail?.errors?.join('\n')||JSON.stringify(detail)||response.statusText);}return data;}
async function save(){const definition=definitionFromForm();if(saved&&currentId===definition.metadata.id){await request(`/simulations/${encodeURIComponent(currentId)}`,{method:'PUT',body:JSON.stringify(definition)});}else{await request('/simulations',{method:'POST',body:JSON.stringify(definition)});saved=true;currentId=definition.metadata.id;}loadDefinition(definition,true);await refreshSaved();setStatus('Saved to local JSON');return definition;}
async function refreshSaved(){const items=await request('/simulations');const select=byId('savedSelect');const keep=select.value;select.replaceChildren(new Option('Choose saved simulation…',''));items.forEach(item=>select.add(new Option(item.name,item.simulation_id)));if(items.some(item=>item.simulation_id===keep))select.value=keep;}
async function refreshTemplates(){const items=await request('/simulations/templates');const select=byId('templateSelect');items.forEach(item=>select.add(new Option(item.name,item.id)));}
function clearResults(){byId('summary').textContent='Run a simulation to view results.';byId('tree').textContent='The tree will appear here after a run.';byId('comparison').querySelector('thead').replaceChildren();byId('comparison').querySelector('tbody').replaceChildren();byId('scenarioDetail').textContent='Select a terminal scenario in the tree or comparison table.';resultScenarios=[];nodeIndex={};}
function safePre(title,value){const section=document.createElement('div');section.className='detail-block';const heading=document.createElement('b');heading.textContent=title;const pre=document.createElement('pre');pre.textContent=JSON.stringify(value,null,2);section.append(heading,pre);return section;}
function selectScenario(scenario){
  const target=byId('scenarioDetail');target.replaceChildren();const heading=document.createElement('h3');heading.textContent=scenario.name;target.append(heading);
  const lineage=[];let node=nodeIndex[scenario.terminal_node_id];while(node){lineage.push(node);node=node.parent_node_id?nodeIndex[node.parent_node_id]:null;}lineage.reverse();
  target.append(safePre('Complete lineage',lineage.map(n=>({node_id:n.node_id,node_type:n.node_type,status:n.status,event:n.triggering_event,agent:n.acting_agent,action:n.selected_action,state:n.world_state.variables}))));
  target.append(safePre('Actions taken',scenario.actions));target.append(safePre('Triggering events',scenario.decision_trace.filter(t=>t.event).map(t=>t.event)));
  target.append(safePre('World-state changes',scenario.decision_trace.filter(t=>Object.keys(t.state_changes||{}).length).map(t=>({time:t.time,type:t.event_type,changes:t.state_changes}))));
  target.append(safePre('Final state',scenario.final_state));target.append(safePre('Forecast',scenario.forecast));target.append(safePre('Decision trace',scenario.decision_trace));
}
function drawTree(root,scenarios){
  const tree=byId('tree');tree.replaceChildren();nodeIndex={};const walk=n=>{nodeIndex[n.node_id]=n;(n.children||[]).forEach(walk)};walk(root);
  const scenarioByNode=new Map(scenarios.map(s=>[s.terminal_node_id,s]));
  function addNode(node,parent){
    const details=document.createElement('details');details.open=node.node_type==='root'||node.node_type==='decision';
    const summary=document.createElement('summary');summary.className=node.status;
    let label=node.node_type==='root'?'ROOT':node.node_type==='decision'?`${node.acting_agent}: ${node.selected_action?.name||'decision'}`:node.node_type==='event'?`${node.triggering_event?.event_type||'event'}: ${node.triggering_event?.description||''}`:`Transition${node.triggering_event?.description?': '+node.triggering_event.description:''}`;
    if(node.status==='pruned')label+=` [PRUNED: ${node.pruning_reason||''}]`;if(node.status==='terminal')label+=' [TERMINAL]';summary.textContent=label;details.append(summary);
    const scenario=scenarioByNode.get(node.node_id);if(scenario){const btn=document.createElement('button');btn.textContent=`Inspect ${scenario.scenario_id}`;btn.onclick=()=>selectScenario(scenario);details.append(btn);}
    if(node.status==='pruned'&&node.pruning_policy){const p=document.createElement('small');p.textContent=`Policy: ${node.pruning_policy}; retained comparison: ${node.competing_retained_node_id||'none'}`;details.append(p);}
    (node.children||[]).forEach(child=>addNode(child,details));parent.append(details);
  }
  addNode(root,tree);
}
function drawComparison(scenarios){
  const table=byId('comparison'),head=table.querySelector('thead'),body=table.querySelector('tbody');head.replaceChildren();body.replaceChildren();
  const keys=[...new Set(scenarios.flatMap(s=>Object.keys(s.forecast?.metrics||{})))];const tr=document.createElement('tr');['Scenario',...keys].forEach(key=>{const th=document.createElement('th');th.textContent=key;tr.append(th)});head.append(tr);
  scenarios.forEach(s=>{const row=document.createElement('tr');const first=document.createElement('td');const btn=document.createElement('button');btn.className='subtle';btn.textContent=s.name;btn.onclick=()=>selectScenario(s);first.append(btn);row.append(first);keys.forEach(k=>{const td=document.createElement('td');td.textContent=s.forecast?.metrics?.[k]??'—';row.append(td)});body.append(row);});
}
async function runSimulation(){await save();await request(`/simulations/${encodeURIComponent(currentId)}/validate`,{method:'POST'});const runInfo=await request(`/simulations/${encodeURIComponent(currentId)}/run`,{method:'POST'});const results=await request(`/simulations/${encodeURIComponent(currentId)}/results`);const tree=await request(`/simulations/${encodeURIComponent(currentId)}/tree`);resultScenarios=results.scenarios;
  const summary=results.summary;byId('summary').innerHTML='';[['Terminal scenarios',summary.terminal_scenarios],['Pruned nodes',summary.pruned_nodes],['Duration (s)',summary.duration_seconds.toFixed(4)],['Forecast model',summary.forecast_model||'none'],['Scenario policy',summary.scenario_policy]].forEach(([k,v])=>{const d=document.createElement('div');d.className='metric';const b=document.createElement('b');b.textContent=v;const small=document.createElement('span');small.textContent=k;d.append(b,small);byId('summary').append(d)});
  drawTree(tree.root,resultScenarios);drawComparison(resultScenarios);setStatus(`Run complete: ${runInfo.scenario_count} scenarios`);
}

byId('addVariable').onclick=()=>addVariableRow();
byId('newBtn').onclick=()=>{loadDefinition(blankDefinition(),false);saved=false;currentId=null;};
byId('saveBtn').onclick=async()=>{try{await save();byId('errors').textContent='';}catch(e){byId('errors').textContent=e.message;setStatus('Save failed',true);}};
byId('loadBtn').onclick=async()=>{try{const id=byId('savedSelect').value;if(!id)throw new Error('Choose a saved simulation first.');const data=await request(`/simulations/${encodeURIComponent(id)}`);loadDefinition(data.definition,true);}catch(e){byId('errors').textContent=e.message;setStatus('Load failed',true);}};
byId('templateLoadBtn').onclick=async()=>{try{const id=byId('templateSelect').value;if(!id)throw new Error('Choose a template first.');const d=await request(`/simulations/templates/${encodeURIComponent(id)}`);loadDefinition(d,false);saved=false;}catch(e){byId('errors').textContent=e.message;setStatus('Template load failed',true);}};
byId('validateBtn').onclick=async()=>{try{const d=definitionFromForm();const result=await request('/simulations/validate',{method:'POST',body:JSON.stringify(d)});byId('errors').textContent='';setStatus(result.valid?'Definition is valid':'Validation failed');}catch(e){byId('errors').textContent=e.message;setStatus('Validation failed',true);}};
byId('runBtn').onclick=async()=>{try{byId('errors').textContent='';await runSimulation();}catch(e){byId('errors').textContent=e.message;setStatus('Run failed',true);}};
byId('duplicateBtn').onclick=async()=>{try{if(!saved)await save();const d=await request(`/simulations/${encodeURIComponent(currentId)}/duplicate`,{method:'POST'});await refreshSaved();const loaded=await request(`/simulations/${encodeURIComponent(d.simulation_id)}`);loadDefinition(loaded.definition,true);}catch(e){byId('errors').textContent=e.message;setStatus('Duplicate failed',true);}};
byId('savedSelect').onchange=async()=>{const id=byId('savedSelect').value;if(!id)return;try{const d=await request(`/simulations/${encodeURIComponent(id)}`);loadDefinition(d.definition,true);}catch(e){setStatus(e.message,true);}};
Promise.all([refreshSaved(),refreshTemplates()]).then(()=>loadDefinition(blankDefinition(),false)).catch(e=>setStatus(e.message,true));
