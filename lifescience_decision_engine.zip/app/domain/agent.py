"""Generic agent definitions and branch-local runtime memory."""
from typing import Any
from pydantic import BaseModel, Field
from .action import Action

class AgentDefinition(BaseModel):
    """User-configured objectives, observations, actions, and policy rules."""
    id: str
    name: str
    type: str = "generic"
    objective: str
    constraints: dict[str, Any] = Field(default_factory=dict)
    observable_state: list[str] | str = "all"
    available_actions: list[str] = Field(default_factory=list)
    decision_policy: dict[str, Any] = Field(default_factory=lambda: {"type": "rule_based", "rules": []})
    memory_configuration: dict[str, Any] = Field(default_factory=dict)

class AgentState(BaseModel):
    """Persistent strategy and decision memory for one scenario path."""
    agent_id: str
    current_strategy: str | None = None
    previous_actions: list[str] = Field(default_factory=list)
    last_decision_time: int | None = None
    reason_current_strategy: str = ""
    relevant_observations: dict[str, Any] = Field(default_factory=dict)
    memory: list[dict[str, Any]] = Field(default_factory=list)
    last_trigger_times: dict[str, int] = Field(default_factory=dict)

    def remember(self, action: Action, time: int, trigger: str, rationale: str,
                 observations: dict[str, Any]) -> None:
        """Persist the selected strategy and its decision context."""
        self.current_strategy = action.name
        self.previous_actions.append(action.name)
        self.last_decision_time = time
        self.reason_current_strategy = rationale
        self.relevant_observations = dict(observations)
        self.memory.append({"time": time, "action": action.name, "trigger": trigger,
                            "rationale": rationale, "observations": dict(observations)})

# Compatibility name for older example factories. New definitions use AgentDefinition.
class Agent(AgentDefinition):
    """Legacy combined definition/runtime object retained for sample factories."""
    current_strategy: str | None = None
    previous_actions: list[str] = Field(default_factory=list)
    last_decision_time: int | None = None
    reason_current_strategy: str = ""
    relevant_observations: dict[str, Any] = Field(default_factory=dict)
    memory: list[dict[str, Any]] = Field(default_factory=list)

    def observe(self, state) -> dict[str, Any]:
        """Return only configured observable state, or all variables."""
        values = state.as_variables()
        if self.observable_state == "all":
            return values
        return {key: values[key] for key in self.observable_state if key in values}

    def action(self, name: str, category: str, parameters: dict, description: str) -> Action:
        """Create an available action record for older example code."""
        if name not in self.available_actions:
            raise ValueError(f"{name!r} is not available to agent {self.id}")
        return Action(action_id=f"{self.id}:{name}", agent_id=self.id, name=name,
                      category=category, parameters=parameters, description=description)
