"""Application service that assembles forecast plugins and executes definitions."""
from time import perf_counter

from app.domain.definitions import SimulationDefinition
from app.forecasting.launch_forecast import LaunchForecast
from app.forecasting.registry import ForecastRegistry
from app.forecasting.state_metrics import StateMetricsForecast
from app.simulation.engine import SimulationEngine


class SimulationRunnerService:
    def run(self, definition: SimulationDefinition):
        registry = ForecastRegistry()
        registry.register("launch_revenue", LaunchForecast())
        registry.register("state_metrics", StateMetricsForecast())
        started = perf_counter()
        result = SimulationEngine(registry).run(definition)
        return result, perf_counter() - started
