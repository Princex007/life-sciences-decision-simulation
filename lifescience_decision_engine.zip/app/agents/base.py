"""Generic deterministic decision-policy interface and implementation."""
from typing import Protocol
from app.domain.action import ActionDefinition
from app.domain.agent import AgentDefinition, AgentState
from app.domain.world import WorldState

class DecisionPolicy(Protocol):
    """A policy returns plausible configured actions and can select one."""
    def get_plausible_actions(self, definition: AgentDefinition, state: AgentState,
                              world: WorldState, actions: dict[str, ActionDefinition], trigger: str) -> list[ActionDefinition]: ...
    def choose_action(self, state: AgentState, actions: list[ActionDefinition]) -> ActionDefinition: ...

class RuleBasedDecisionPolicy:
    """Evaluate generic JSON rule conditions and return referenced actions."""
    def get_plausible_actions(self, definition: AgentDefinition, state: AgentState,
                              world: WorldState, actions: dict[str, ActionDefinition], trigger: str = "") -> list[ActionDefinition]:
        config = definition.decision_policy
        available = [actions[action_id] for action_id in definition.available_actions if action_id in actions]
        for rule in config.get("rules", []):
            if rule.get("when_event") and rule["when_event"] != trigger:
                continue
            conditions = rule.get("when", [])
            if self._all_conditions(conditions, world):
                selected = rule.get("plausible_actions", [])
                return [actions[action_id] for action_id in selected
                        if action_id in actions and actions[action_id].agent_id == definition.id]
        defaults = config.get("default_actions", definition.available_actions)
        return [actions[action_id] for action_id in defaults
                if action_id in actions and actions[action_id].agent_id == definition.id]

    @staticmethod
    def plausible_action_reason(definition: AgentDefinition, world: WorldState,
                                trigger: str) -> str:
        """Explain why the configured rule returned this candidate set."""
        for rule in definition.decision_policy.get("rules", []):
            if rule.get("when_event") and rule["when_event"] != trigger:
                continue
            if RuleBasedDecisionPolicy._all_conditions(rule.get("when", []), world):
                return rule.get("reason", f"Rule conditions matched for event '{trigger}'.")
        return definition.decision_policy.get("default_reason", "Configured default action set.")

    def choose_action(self, state: AgentState, actions: list[ActionDefinition]) -> ActionDefinition:
        """Use persistent strategy when available, otherwise the first ranked rule."""
        if not actions:
            raise ValueError("Cannot choose from an empty plausible-action set")
        return next((action for action in actions if action.id == state.current_strategy), actions[0])

    @staticmethod
    def _all_conditions(conditions: list[dict], world: WorldState) -> bool:
        return all(RuleBasedDecisionPolicy._condition(condition, world) for condition in conditions)

    @staticmethod
    def _condition(condition: dict, world: WorldState) -> bool:
        variable = condition.get("variable")
        actual = world.get(variable)
        expected = condition.get("value")
        if isinstance(expected, dict) and "variable" in expected:
            expected = world.get(expected["variable"])
        operator = condition.get("operator", "eq")
        operations = {"gt": lambda: actual > expected, "gte": lambda: actual >= expected,
                      "lt": lambda: actual < expected, "lte": lambda: actual <= expected,
                      "eq": lambda: actual == expected, "neq": lambda: actual != expected}
        return bool(operations[operator]()) if operator in operations and actual is not None else False
