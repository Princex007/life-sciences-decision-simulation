"""Generic event and trigger driven simulation orchestration."""
from app.agents.base import RuleBasedDecisionPolicy
from app.domain.definitions import SimulationDefinition
from app.domain.scenario import Scenario, SimulationResult
from app.domain.world import WorldState
from app.forecasting.registry import ForecastRegistry
from .scenario_generator import ScenarioGenerator, SimulationPath
from .scenario_pruning import create_pruner
from .scheduler import EventScheduler
from .state_transition import StateTransitionSystem

class SimulationEngine:
    """Execute JSON-defined events, triggers, policies, and transition rules."""
    def __init__(self, forecast_registry: ForecastRegistry | None = None):
        self.forecast_registry = forecast_registry or ForecastRegistry()

    def run(self, definition: SimulationDefinition) -> SimulationResult:
        settings = definition.settings
        if settings.time_horizon < 1:
            raise ValueError("time_horizon must be positive")
        generator = ScenarioGenerator(create_pruner(definition.scenario_generation))
        transition = StateTransitionSystem()
        scheduler = EventScheduler(definition)
        policy = RuleBasedDecisionPolicy()
        root_path, root = generator.root_path(definition.initial_world_state, definition.agents)
        paths = [root_path]
        for time in range(0, settings.time_horizon + 1):
            if time:
                advanced = []
                for path in paths:
                    path._previous_world = path.world.model_copy(deep=True)
                    event = scheduler.advance(path.world)
                    result = transition.apply_event(path.world, event, definition.transition_rules)
                    generator.append_transition(path, event, result)
                    path.snapshots.append(path.world.model_copy(deep=True))
                    advanced.append(path)
                paths = advanced
            events = scheduler.initial_events() if time == 0 else scheduler.scheduled_events(time)
            paths = self._resolve(paths, events, time, definition, scheduler, generator, transition, policy)
        scenarios = []
        for index, path in enumerate(paths, 1):
            path.cursor.status = "terminal"
            scenario = Scenario(scenario_id=f"scenario-{index:03d}", name=self._name(path, definition),
                actions=path.actions, final_state=path.world, key_drivers=[], decision_trace=path.trace,
                snapshots=path.snapshots, agent_states=list(path.agents.values()), terminal_node_id=path.cursor.node_id)
            forecast_id = definition.forecast_model_id
            if forecast_id:
                model = self.forecast_registry.get(forecast_id)
                scenario.forecast = model.forecast(path.world, path.snapshots, scenario)
            scenarios.append(scenario)
        return SimulationResult(simulation_id=definition.metadata.id, name=definition.metadata.name,
            root=root, scenarios=scenarios, pruning_records=generator.pruning_records)

    def _resolve(self, paths, events, time, definition, scheduler, generator, transition, policy):
        for path in paths:
            path.decided_agents.clear()
        while True:
            next_paths = []
            did_branch = False
            for path in paths:
                previous = getattr(path, "_previous_world", None)
                path_events = getattr(path, "_pending_events", events)
                recorded = {item.event.event_id for item in path.trace if item.event is not None}
                for event in path_events:
                    if event.event_id not in recorded:
                        generator.append_event(path, event)
                        recorded.add(event.event_id)
                matches = []
                for agent in definition.agents:
                    if agent.id in path.decided_agents:
                        continue
                    match = scheduler.dispatch(agent, path.agents[agent.id], path.world,
                                               path_events, previous, time)
                    if match:
                        matches.append((match.definition.priority, agent.id, agent, match))
                if not matches:
                    if hasattr(path, "_pending_events"):
                        del path._pending_events
                    next_paths.append(path)
                    continue
                _, _, agent, match = sorted(matches, key=lambda item: (-item[0], item[1]))[0]
                action_map = {item.id: item for item in definition.action_definitions
                              if item.agent_id == agent.id}
                definitions = policy.get_plausible_actions(agent, path.agents[agent.id], path.world,
                                                           action_map, match.event.event_type)
                alternative_reason = policy.plausible_action_reason(agent, path.world, match.event.event_type)
                if not definitions:
                    path.decided_agents.add(agent.id)
                    path._pending_events = path_events
                    next_paths.append(path)
                    continue
                branches = generator.branch(path, agent, match, definitions, transition, time, alternative_reason)
                for child, result in branches:
                    generated = result.events + scheduler.state_change_events(result.previous_state, result.state)
                    child_events = scheduler.transition_events(path_events + generated)
                    child._pending_events = child_events
                    next_paths.append(child)
                did_branch = True
            paths = next_paths
            if not did_branch:
                return generator.prune(paths, time)

    @staticmethod
    def _name(path: SimulationPath, definition: SimulationDefinition) -> str:
        names = {agent.id: agent.name for agent in definition.agents}
        decisions = [f"{names.get(item.agent_id, item.agent_id)}: {item.action.name}"
                     for item in path.trace if item.event_type == "decision" and item.action]
        return " / ".join(decisions) or "Baseline"
