# Generic Simulation Platform MVP

A deterministic simulation kernel that loads world variables, agents, actions, triggers, transitions, settings, forecasts, and pruning behavior from a JSON `SimulationDefinition`. The bundled US drug launch is an example domain configuration; the engine does not construct pharma agents or encode pharma state fields.

## Run

From the repository root:

```powershell
python -m app.run_simulation examples/us_drug_launch.json
python -m app.run_simulation examples/us_drug_launch.json --json
python -m pytest -q
uvicorn app.main:app --reload
```

The CLI prints an ASCII tree of retained terminal paths, scenario traces, final states, and forecast outputs. JSON mode prints the full tree and terminal scenarios. The FastAPI API accepts the same `SimulationDefinition`; its in-memory store resets when the process exits.

The local builder UI is served at `http://127.0.0.1:8000/` after starting the API with `uvicorn app.main:app --reload`. Definitions are saved as JSON under `simulations/` in the project directory. Run results live in memory until the server exits. The UI can load either bundled example as a template, edit and validate a definition, save or duplicate it, run it, browse the scenario tree, inspect a terminal scenario, and compare forecast metrics. API schema and template routes are available at `/simulations/schema` and `/simulations/templates`; saved-definition CRUD and run routes are under `/simulations`.

## Configuration

`examples/us_drug_launch.json` is the source of truth for the example. `SimulationDefinition` contains metadata, generic world variables, agent definitions and rule policies, action effects, event/state triggers, event-based transition rules, clock and scheduled events, forecast model ID, and scenario pruning settings. Expressions in effects use arithmetic over world variables and action parameters. The scheduler orders events, dispatches configured triggers, and advances time. Strategies persist in per-path agent memory; reselecting an unchanged strategy records the decision without replaying one-time action effects.

`ScenarioNode` stores parent and child lineage, state snapshots, triggering events, plausible actions, selections, and rationale. Nodes are marked `active`, `pruned`, or `terminal`; pruned nodes include policy, reason, and any retained comparison node. Only retained terminal paths receive forecasts. `ScenarioPolicy` supports `exhaustive` with a safety limit, `diversity` with configured decision dimensions, and deterministic `limited` retention.

`DecisionValidator` checks action ownership and availability, trigger activation, compatibility conditions, and constraints before applying effects. Constraints can use `{"state":{"variable":{"min":0,"max":1}}}`, `{"parameters":{"budget":{"lte":100}}}`, or condition lists using `variable`, `operator`, and `value`. State constraints check the projected post-action state; `current_state` is also supported. Decision traces contain observations, current strategy, plausible alternatives, policy rationale, and validity reason. Forecast plugins are registered by the application boundary; `LaunchForecast` is the example implementation.

## Launch forecast equation

For every saved world-state snapshot, the launch forecast computes:

```text
eligible_patients = addressable_patients × diagnosis_rate × treatment_rate × payer_access
patients_treated  = int(eligible_patients × market_share)
net_price         = net_price, when supplied; otherwise drug_price × 0.85
period_revenue    = patients_treated × net_price
peak_sales        = maximum period_revenue across snapshots
cumulative_sales  = sum of period_revenue across snapshots
```

`patients_treated` reports the last snapshot's treated count, and `market_share` reports the last snapshot's share. These equations are covered by hand-calculated deterministic fixtures in `tests/test_forecasting.py`, including zero/full access, penetration changes, price scaling, and the fallback discount.

## Current limitations

- Action and agent constraint fields are represented in the schema but are not yet enforced by the rule policy or transition system.
- Trigger state conditions support simple variable comparisons and numeric deltas; there is no compound condition language.
- The diversity policy retains representative terminal paths, while the tree can include explored branches that were later pruned.
- JSON expressions are intentionally a small arithmetic subset. Forecast behavior is Python plug-in code, not JSON-defined.
- The launch model is illustrative and uncalibrated; it is not clinical, regulatory, or commercial advice.
- The browser editor exposes core definition fields and JSON editors for agent, action, trigger, transition, and event schedule collections; forecast plugins and supported effect expressions remain code-defined.
